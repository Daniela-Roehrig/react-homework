

const ParagraphsComponent = () => {
    return (
      <div>
        <h1>Заголовок первого параграфа</h1>
        <p>Это первый параграф текста. Lorem ipsum dolor sit amet.</p>
        
        <h2>Заголовок второго параграфа</h2>
        <p>Это второй параграф текста. Sed do eiusmod tempor incididunt.</p>
        
        <h3>Заголовок третьего параграфа</h3>
        <p>Это третий параграф текста. Ut labore et dolore magna aliqua.</p>
      </div>
    );
  };
  
  export default ParagraphsComponent;
  