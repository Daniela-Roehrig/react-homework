

const ImageComponent = () => {
    return (
      <div>
        <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT2Euhwt3IuUMw-Dq3btDbPz8YrOqO59OE5IQ&s" alt="Placeholder" />
      </div>
    );
  };
  
  export default ImageComponent;
  